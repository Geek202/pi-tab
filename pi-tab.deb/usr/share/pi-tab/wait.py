#!/usr/bin/env python
try:
	while 1:
		pass
finally:
	print "Done"
