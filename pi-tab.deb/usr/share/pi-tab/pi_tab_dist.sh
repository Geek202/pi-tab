#!/bin/bash
cd ~/Desktop
tar czf ~/Desktop/pi-tab-dist.tar.gz pi-tab
